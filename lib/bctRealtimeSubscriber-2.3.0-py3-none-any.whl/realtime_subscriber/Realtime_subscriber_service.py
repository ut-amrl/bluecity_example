from realtime_subscriber import realtime_subscriber_pb2_grpc
from realtime_subscriber import Realtime_subscriber
import grpc
import time

from realtime_subscriber import header_manipulator_client_interceptor



class Sub_serviceAuth(grpc.AuthMetadataPlugin):
    def __init__(self, udid, key,service):
        self._udid=udid
        self._key = key
        self.service=service

        super().__init__()

    def __call__(self, context, callback):
        # callback((('bct-udid', self._udid),('rpc-auth-header-subscriber-user', self._key)), None)
        callback((('bct-udid', self._udid),('token', self._key),('type', '3'),("service",self.service)), None)




class BCTWSConnection(Realtime_subscriber.BCTWSConnection):

    def __init__(self, UDID, token,service, serverAddress=None,beaconAddress="https://realtime.us.beacon.1.api.bluecity.ai/",subscriptions=(Realtime_subscriber.BCTWSConnection.subscriptionOption.FRAME,), cacheSize=400,singleton=False):
        self.service= service
        super().__init__( UDID, token, serverAddress=serverAddress,beaconAddress=beaconAddress,subscriptions=subscriptions, cacheSize=cacheSize,singleton=singleton)
    
    def connect_secure(self):
        while True:
            try:
                self.logger.info("connecting to realtime server")
                if self.askBeacon:
                    self.getCredentials_beacon()

                call_credentials = grpc.metadata_call_credentials(Sub_serviceAuth(self.UDID,self.token,self.service),"subAuth")
                channel_credential = grpc.ssl_channel_credentials(self.crt)
                composite_credentials= grpc.composite_channel_credentials(channel_credential,call_credentials)
                with grpc.secure_channel('{}'.format(self.serverAdd), composite_credentials) as channel:
                    stub = realtime_subscriber_pb2_grpc.SubscriberStub(channel)
                    self.__subscribe(stub)
            except Exception as ex:
                if self.askBeacon:
                    self.serverAdd=None
                self.logger.critical(str(ex))
                time.sleep(10)    
    
    def connect_insecure(self):
        while True:
            try:
                self.logger.info("connecting to realtime server")
                if self.askBeacon:
                    self.getCredentials_beacon()
                    
                with grpc.insecure_channel(self.serverAdd) as channel:
                    header_adder_interceptor = header_manipulator_client_interceptor.header_adder_interceptor(['bct-udid','token','type','service'], [self.UDID,self.token,'3',self.service])
                    intercept_channel = grpc.intercept_channel(channel,header_adder_interceptor)

                    stub = realtime_subscriber_pb2_grpc.SubscriberStub(intercept_channel)

                    # threading.Thread(target=self.ping,args=[stub]).start()
                    self.__subscribe(stub)
            except: 
                if self.askBeacon:
                    self.serverAdd=None
                self.logger.error("Connection to the server is lost. Retry in 5 seconds")
                time.sleep(10)           


